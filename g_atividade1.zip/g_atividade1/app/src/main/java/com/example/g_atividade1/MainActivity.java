package com.example.g_atividade1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Layout da tela
        btnEnviar = (Button) findViewById(R.id.botaoEnviar);
        btnEnviar.setOnClickListener(this);
        getSupportActionBar().setTitle("Aula 2 - Tópicos");
    }

    @Override
    public void onClick(View view){
        if(view.getId()==R.id.botaoEnviar){
            Intent intent = new Intent(getApplicationContext(),BoasVindas.class);
            startActivity(intent);
        }
    }
}
